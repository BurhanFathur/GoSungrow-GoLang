package cmd

const (
	ArgsDateInterval = "[YYYYmmdd[HHMMSS] | .] [YYYYmmdd[HHMMSS] | .] [interval | .]"
)